var express = require('express');
var router = express.Router();
const bcrypt = require('bcrypt');

const { minRank } = require('./rank');

/* GET users listing. */
router.get('/', function(req, res, next) {
    res.send('respond with a resource');
});

// 회원가입 요청 처리
router.post('/signup', async (req, res) => {
    try {
        const db = req.app.get('database');
        const users = db.collection('users');
        const { email, password, nickname, profileImageIndex } = req.body;
        
        const existingUser = await users.findOne({ email });
        if (existingUser) {
            return res.status(400).send("이미 존재하는 이메일 주소입니다.");
        }
        
        const existingNickname = await users.findOne({ nickname });
        if (existingNickname) {
            return res.status(409).send("이미 사용 중인 닉네임입니다.");
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        await users.insertOne({
            email,
            password: hashedPassword,
            profileImageIndex,
            nickname,
            rank: minRank,
            win: 0,
            lose: 0,
            coins: 0,
            rankPoints: 0,
            rankAchievedTime: null
        });

        res.status(201).send("회원가입 성공");
        console.log('Request Body:', req.body);

    } catch (error) {
        console.error("회원가입 오류:", error);
        res.status(500).send("서버 오류가 발생했습니다.");
    }
});

// 로그인 요청 처리
router.post('/signin', async (req, res) => {
    try {
        const db = req.app.get('database');
        const users = db.collection('users');
        const { email, password } = req.body;

        const user = await users.findOne({ email });
        if (!user) {
            // return res.status(401).send("존재하지 않는 이메일 주소입니다.");
            return res.status(401).json({result : 0, message : "존재하지 않는 이메일 주소입니다."});            
        }

        const passwordMatch = await bcrypt.compare(password, user.password);
        if (!passwordMatch) {
            // return res.status(401).send("비밀번호가 일치하지 않습니다.");
            return res.status(401).send({result : 1, message : "비밀번호가 일치하지 않습니다."});
        }

        req.session.user = { email: user.email, nickname: user.nickname };
        req.session.isAuthenticated = true;
        req.session.save(() => {
            // res.status(200).send("로그인 성공"); // "로그인 성공" 이라는 문자열 반환
            res.status(200).json({ result : 2, message : "로그인 성공",
                 profileImageIndex: user.profileImageIndex, nickname: user.nickname});
        });

    } catch (error) {
        console.error("로그인 오류:", error);
        res.status(500).send("서버 오류가 발생했습니다.");
    }
});

// 닉네임 설정 요청 처리
router.post('/setnickname', async (req, res) => {
    try {
        if (!req.session.isAuthenticated) {
            return res.status(401).send("로그인이 필요합니다.");
        }

        const db = req.app.get('database');
        const users = db.collection('users');
        const { nickname } = req.body;
        const userEmail = req.session.user.email;
        console.log("nickname : " + nickname);

        const existingNickname = await users.findOne({ nickname });
        if (existingNickname) {
            return res.status(409).send("이미 사용 중인 닉네임입니다.");
        }

        const result = await users.updateOne(
            { email: userEmail },
            { $set: { nickname: nickname } }
        );

        if (result.modifiedCount > 0) {
            req.session.user.nickname = nickname;
            req.session.save(() => {
                res.status(200).send({ message: "닉네임이 설정되었습니다.", nickname: nickname });
            });
        } else {
            res.status(404).send("사용자를 찾을 수 없습니다.");
        }

    } catch (error) {
        console.error("닉네임 설정 오류:", error);
        res.status(500).send("서버 오류가 발생했습니다.");
    }
});

// 로그아웃 요청 처리
router.post('/signout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error("로그아웃 오류:", err);
            return res.status(500).send("로그아웃 실패");
        }
        res.send("로그아웃 성공");
    });
});

// 닉네임을 포함한 유저 데이터 조회 (로그인된 사용자)
router.get('/me', async (req, res) => {
    try {
        if (!req.session.isAuthenticated) {
            return res.status(401).send("로그인이 필요합니다.");
        }

        const db = req.app.get('database');
        const users = db.collection('users');
        const userEmail = req.session.user.email;

        const user = await users.findOne({ email: userEmail });

        if (user) {
            const userData = {
                email: user.email,
                nickname: user.nickname,
                rank: user.rank,
                win: user.win,
                lose: user.lose,
                coins: user.coins,
                rankPoints: user.rankPoints,
                profileImageIndex: user.profileImageIndex,
                rankAchievedTime: user.rankAchievedTime
            };
            res.status(200).json(userData);
        } else {
            res.status(404).send("사용자를 찾을 수 없습니다.");
        }

    } catch (error) {
        console.error("유저 데이터 조회 오류:", error);
        res.status(500).send("서버 오류가 발생했습니다.");
    }
});

// 프로필 이미지 업데이트
router.post('/updateProfileImage', async (req, res) => {
    try {
        if (!req.session.isAuthenticated) {
            return res.status(401).send("로그인이 필요합니다.");
        }

        const db = req.app.get('database');
        const users = db.collection('users');
        const { profileImageIndex } = req.body;
        const userEmail = req.session.user.email;

        console.log(`Updating profile image for ${userEmail} to index ${profileImageIndex}`);
        console.log('Request Body:', req.body);

        const result = await users.updateOne(
            { email: userEmail },
            { $set: { profileImageIndex: profileImageIndex } }
        );

        if (result.modifiedCount > 0) {
            res.status(200).json({
                message: "프로필 이미지가 업데이트되었습니다.",
                profileImageIndex: profileImageIndex  // 업데이트된 이미지 인덱스를 반환
            });
        } else {
            console.log("사용자를 찾을 수 없음");
            res.status(404).send("사용자를 찾을 수 없습니다.");
        }
    } catch (error) {
        console.error("프로필 이미지 업데이트 오류:", error);
        res.status(500).send("서버 오류가 발생했습니다.");
    }
});

module.exports = router;