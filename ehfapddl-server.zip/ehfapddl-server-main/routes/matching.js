const { Server } = require("socket.io");

module.exports = (server) => {
    const io = new Server(server);
    const waitingQueue = [];

    // TODO: 클라이언트에 맞게 수정, 매칭 제한 시간: 60초
    const matchingTime = 60000; // 1000: 1초

    io.on('connection', (socket) => {
        console.log('클라이언트 연결:', socket.id);

        socket.on('joinMatchQueue', async (userData) => {
            const { email, rank, nickname } = userData;
            socket.email = email;
            socket.rank = rank;
            socket.nickname = nickname;

            waitingQueue.push({ socket: socket, joinTime: Date.now(), email: email, nickname: nickname });
            console.log(`[${nickname}] 님이 매칭 큐에 참여했습니다. 현재 대기 인원: ${waitingQueue.length}`);

            // 즉시 매칭 시도
            attemptMatch();
        });

        socket.on('cancelMatchmaking', () => {
            const index = waitingQueue.findIndex(playerInfo => playerInfo.socket.id === socket.id);
            if (index > -1) {
                const playerInfo = waitingQueue.splice(index, 1)[0];
                console.log(`[${playerInfo.nickname}] 님이 매칭을 취소했습니다. 현재 대기 인원: ${waitingQueue.length}`);
                socket.emit('matchmakingCancelled');
                socket.isMatchmakingCancelled = true;
            }
        });
        
        socket.on('disconnect', () => {
            console.log('클라이언트 연결 해제:', socket.id);
            if (!socket.isMatchmakingCancelled) {
                const index = waitingQueue.findIndex(playerInfo => playerInfo.socket.id === socket.id);
                if (index > -1) {
                    const playerInfo = waitingQueue.splice(index, 1)[0];
                    console.log(`[${playerInfo.nickname}] 님이 매칭 큐에서 나갔습니다. 현재 대기 인원: ${waitingQueue.length}`);
                }
            } else if(socket.isMatchmakingCancelled) {
                console.log(`[${socket.nickname}] 님과의 소켓 연결을 종료합니다.`);
            }
        });

        function attemptMatch() {
            if (waitingQueue.length >= 2) {
                const player1Info = waitingQueue[0]; // 큐에서 가장 오래 기다린 플레이어
                const player1 = player1Info.socket;

                // 큐의 나머지 플레이어들과 매칭 시도
                for (let i = 1; i < waitingQueue.length; i++) {
                    const player2Info = waitingQueue[i];
                    const player2 = player2Info.socket;

                    if (Math.abs(player1.rank - player2.rank) <= 1) {
                        // 매칭 성공
                        const matchedPlayer1Info = waitingQueue.shift();
                        const matchedPlayer2Info = waitingQueue.splice(i - 1, 1)[0];

                        // gamePlay.js에 방 생성을 요청하는 이벤트 발생
                        io.emit('createGameRoom', {
                            player1SocketId: matchedPlayer1Info.socket.id,
                            player1Email: matchedPlayer1Info.email,
                            player1Nickname: matchedPlayer1Info.nickname,

                            player2SocketId: matchedPlayer2Info.socket.id,
                            player2Email: matchedPlayer2Info.email,
                            player2Nickname: matchedPlayer2Info.nickname 
                        });

                        console.log(`[매칭 성공] ${matchedPlayer1Info.nickname} vs ${matchedPlayer2Info.nickname}`);
                        return;
                    }
                }

                // 첫 번째 플레이어와 매칭되는 상대를 찾지 못했다면, 큐의 맨 뒤로 보냄
                const firstPlayer = waitingQueue.shift();
                if (firstPlayer) {
                    waitingQueue.push(firstPlayer);
                    if (waitingQueue.length > 0) {
                        const nextFirstPlayer = waitingQueue[0].socket;
                        io.to(nextFirstPlayer.id).emit('waitingForMatch');
                    }
                }
            } else if (waitingQueue.length === 1) {
                const firstInQueue = waitingQueue[0].socket;
                io.to(firstInQueue.id).emit('waitingForMatch');
            }
        }

        // 주기적으로 대기 시간을 확인하고 타임아웃 처리하는 함수
        setInterval(() => {
            const now = Date.now();
            const timedOutPlayers = [];

            for (let i = waitingQueue.length - 1; i >= 0; i--) {
                const playerInfo = waitingQueue[i];
                if (now - playerInfo.joinTime > matchingTime) {
                    const socket = playerInfo.socket;
                    const nickname = socket.nickname;
                    console.log(`[${nickname}] 님 매칭 시간 초과로 AI와 매칭 시도.`);
                    io.to(socket.id).emit('matchWithAI');
                    timedOutPlayers.push(i); // 타임아웃된 플레이어의 인덱스 저장
                }
            }

            // 타임아웃된 플레이어를 큐에서 제거 (역순으로 제거하여 인덱스 변경 문제 방지)
            timedOutPlayers.forEach(index => {
                waitingQueue.splice(index, 1);
            });
        }, 5000); // 5초마다 대기 시간 확인 (주기는 조정 가능)
    });
};