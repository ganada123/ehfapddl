const express = require('express');
const router = express.Router();
const moment = require('moment-timezone');

// 대국 데이터 저장
router.post('/savegamerecord', async (req, res) => {
    try {
        if (!req.session.isAuthenticated) {
            return res.status(401).send("로그인이 필요합니다.");
        }

        const db = req.app.get('database');
        const gameRecords = db.collection('gameRecords');
        const { player1, player2, moves, result } = req.body; // TODO: 클라이언트에 맞게 수정, result는 WIN: 0, LOSE: 1, DRAW: 2

        const nowKST = moment().tz('Asia/Seoul'); /** 한국 시간 기준으로 moment 객체 생성 */ 

        await gameRecords.insertOne({
            player1, // player1 닉네임
            player2, // player2 닉네임
            moves,
            result,
            date: nowKST.toDate(), // Date 객체로 저장 (한국 시간 기준)
            timestamp: nowKST.valueOf() // Unix timestamp (밀리초)로 저장 (한국 시간 기준)
        });

        res.status(201).send("대국 기록이 저장되었습니다.");

    } catch (error) {
        console.error("대국 기록 저장 오류:", error);
        res.status(500).send("서버 오류가 발생했습니다.");
    }
});

// 특정 유저의 대국 기록 불러오기
router.get('/loadgamerecords', async (req, res) => {
    try {
        if (!req.session.isAuthenticated) {
            return res.status(401).send("로그인이 필요합니다.");
        }

        const db = req.app.get('database');
        const gameRecords = db.collection('gameRecords');
        const userNickname = req.session.user.nickname;

        const records = await gameRecords.find({
            $or: [{ player1: userNickname }, { player2: userNickname }]
        }).sort({ timestamp: -1 }).toArray();

        res.status(200).json(records);

    } catch (error) {
        console.error("대국 기록 불러오기 오류:", error);
        res.status(500).send("서버 오류가 발생했습니다.");
    }
});

module.exports = router;