const { Server } = require("socket.io");
const { v4: uuidv4 } = require('uuid');
const moment = require('moment-timezone');

// rank.js에서 필요한 상수 import
const { rankUpPoints, demotionPoints, maxRank, minRank } = require('./rank');

// coin.js에서 필요한 상수 import
const { coinConsumption } = require('./coin');

module.exports = (server) => {
    const io = new Server(server);
    const gameRooms = {};
    const roomReadyStatus = {}; // 방 ID별 플레이어 준비 상태 저장

    // TODO: 클라이언트에 맞게 수정 stone은 ex) 흑돌: "Black", 백돌: "White"
    const STONE_BLACK = "Black";
    const STONE_WHITE = "White";

    // TODO: 클라이언트에 맞게 수정 result는 ex) WIN: 0, LOSE: 1, DRAW: 2
    const Win = 0;
    const Lose = 1;
    const Draw = 2;

    function getRoomInfo(roomId) {
        return gameRooms[roomId];
    }

    function deleteRoom(roomId) {
        delete gameRooms[roomId];
        console.log(`[${roomId}] 방이 종료되었습니다.`);
    }

    // 기보 저장 함수
    async function saveGameRecord(req, player1Nickname, player2Nickname, result, moves, player1Color, player2Color) {
        try {
            const db = req.app.get('database');
            const gameRecords = db.collection('gameRecords');
            const nowKST = moment().tz('Asia/Seoul'); // 한국 시간 기준으로 moment 객체 생성

            await gameRecords.insertOne({
                player1: player1Nickname,
                player2: player2Nickname,
                moves: moves,     // 기보
                result: result,   // 게임 결과
                date: nowKST.toDate(), // Date 객체로 저장 (한국 시간 기준)
                timestamp: nowKST.valueOf(), // Unix timestamp (밀리초)로 저장 (한국 시간 기준)
                player1Color: player1Color,
                player2Color: player2Color
            });
            console.log(`[게임 기록 저장] ${player1Nickname} (${player1Color}) vs ${player2Nickname} (${player2Color}): ${result}, Moves: ${moves.length}`);
        } catch (error) {
            console.error("게임 기록 저장 오류:", error);
        }
    }

    // 게임 승, 패 저장 함수
    async function updateWinLose(req, nickname, isWin) {
        try {
            const db = req.app.get('database');
            const users = db.collection('users');
            const updateQuery = isWin ? { $inc: { win: 1 } } : { $inc: { lose: 1 } };
            await users.updateOne({ nickname: nickname }, updateQuery);
            console.log(`[승패 업데이트] ${nickname}: ${isWin ? '승' : '패'}`);
        } catch (error) {
            console.error("승패 업데이트 오류:", error);
        }
    }

    // 랭크 시스템에 맞춰 랭크 포인트, 랭크(급수), 랭크 달성시간 저장 함수
    async function updateRank(req, nickname, gameResult) {
        try {
            const db = req.app.get('database');
            const users = db.collection('users');
            const user = await users.findOne({ nickname: nickname });
            if (!user) {
                console.error(`[랭크 업데이트 오류] 사용자 ${nickname}을 찾을 수 없습니다.`);
                return;
            }

            let { rank, rankPoints } = user;
            let updatedRank = rank;
            let updatedRankPoints = rankPoints || 0;

            if (gameResult === Win) {
                updatedRankPoints++;
            } else if (gameResult === Lose) {
                updatedRankPoints--;
            }

            const requiredPoints = rankUpPoints[rank];
            if (requiredPoints && updatedRankPoints >= requiredPoints && rank > maxRank) {
                updatedRank--;
                updatedRankPoints = 0;
            }

            if (updatedRankPoints <= demotionPoints && rank < minRank) {
                updatedRank++;
                updatedRankPoints = 0;
            }

            if (updatedRank < maxRank) updatedRank = maxRank;
            if (updatedRank > minRank) updatedRank = minRank;

            const updateSet = { rank: updatedRank, rankPoints: updatedRankPoints };
            if (updatedRank !== rank) {
                updateSet.rankAchievedTime = moment().tz('Asia/Seoul').toDate(); // 한국 시간으로 설정 (Date 객체)
            }

            await users.updateOne(
                { nickname: nickname },
                { $set: updateSet }
            );
            console.log(`[급수 업데이트] ${nickname}: ${rank} -> ${updatedRank} (${updatedRankPoints} 점)`);

        } catch (error) {
            console.error("급수 업데이트 오류:", error);
        }
    }

    io.on('connection', (socket) => {
        // matching.js에서 방 생성을 요청하는 이벤트 핸들러
        socket.on('createGameRoom', async (data) => { // 유저 정보(프로필, 닉네임, 승, 패)를 받아오고 상대방에게 전달
            const { player1SocketId, player1Email, player2SocketId, player2Email, player1Nickname, player2Nickname } = data;
            const newRoomId = uuidv4();

            const player1Socket = io.sockets.sockets.get(player1SocketId);
            const player2Socket = io.sockets.sockets.get(player2SocketId);

            if (!player1Socket || !player2Socket) {
                console.error("플레이어 소켓이 존재하지 않습니다.");
                return;
            }

            const db = socket.request.app.get('database');
            const users = db.collection('users');

            try {
                const player1Data = await users.findOne({ nickname: player1Nickname });
                const player2Data = await users.findOne({ nickname: player2Nickname });

                if (!player1Data || (player1Data.coins || 0) < coinConsumption) {
                    io.to(player1SocketId).emit('matchFailed', { message: "코인이 부족하여 매칭을 시작할 수 없습니다." });
                    console.log(`[${player1Nickname}] 코인 부족으로 매칭 실패.`);
                    return;
                }

                if (!player2Data || (player2Data.coins || 0) < coinConsumption) {
                    io.to(player2SocketId).emit('matchFailed', { message: "코인이 부족하여 매칭을 시작할 수 없습니다." });
                    console.log(`[${player2Nickname}] 코인 부족으로 매칭 실패.`);
                    return;
                }

                // 코인 차감
                await users.updateOne({ nickname: player1Nickname }, { $inc: { coins: -coinConsumption } });
                await users.updateOne({ nickname: player2Nickname }, { $inc: { coins: -coinConsumption } });
                console.log(`[코인 차감] ${player1Nickname}: -${coinConsumption}, ${player2Nickname}: -${coinConsumption}`);

                gameRooms[newRoomId] = {
                    player1SocketId: player1SocketId,
                    player1Email: player1Email,
                    player1Nickname: player1Nickname,
                    player1Color: player1Color,

                    player2SocketId: player2SocketId,
                    player2Email: player2Email,
                    player2Nickname: player2Nickname,
                    player2Color: player2Color,

                    roomId: newRoomId,
                    gameStarted: false, // 초기값 유지
                    player1Disconnected: false,
                    player2Disconnected: false,
                    drawRequestedBy: null,
                    turnCount: 0,
                    moves: []
                };

                const randomNumber = Math.floor(Math.random() * 2); // 0 또는 1
                let player1Color, player2Color;

                if (randomNumber === 0) {
                    player1Color = STONE_BLACK;
                    player2Color = STONE_WHITE;
                } else {
                    player1Color = STONE_WHITE;
                    player2Color = STONE_BLACK;
                }

                // 각 플레이어에게 방 ID 및 색깔 정보 전송
                if (player1Socket) {
                    player1Socket.join(newRoomId);
                    player1Socket.emit('roomCreatedForMatch', { roomId: newRoomId }); // 매칭 후 방 생성
                    player1Socket.room = newRoomId;
                    player1Socket.email = player1Email;
                    player1Socket.nickname = player1Nickname;
                    console.log(`[${player1Nickname}] 님에게 매칭 후 생성된 방 ID ${newRoomId} 및 색깔(${player1Color}) 전송`);
                    io.to(player1SocketId).emit('setColor', { opponentNickname: player2Nickname, myColor: player1Color, roomId: newRoomId });
                }

                if (player2Socket) {
                    player2Socket.join(newRoomId);
                    player2Socket.emit('roomCreatedForMatch', { roomId: newRoomId }); // 매칭 후 방 생성
                    player2Socket.room = newRoomId;
                    player2Socket.email = player2Email;
                    player2Socket.nickname = player2Nickname;
                    console.log(`[${player2Nickname}] 님에게 매칭 후 생성된 방 ID ${newRoomId} 및 색깔(${player2Color}) 전송`);
                    io.to(player2SocketId).emit('setColor', { opponentNickname: player1Nickname, myColor: player2Color, roomId: newRoomId });
                }

                // 색을 각 클라이언트 화면에 표시 or 룰렛 연출 시작 신호
                io.to(newRoomId).emit('showColor');

                console.log(`[방 생성됨 (매칭)] Room ID: ${newRoomId},
                    Player 1: ${player1Nickname} (${player1Color === STONE_BLACK ? 'Black' : 'White'}),
                    Player 2: ${player2Nickname} (${player2Color === STONE_BLACK ? 'Black' : 'White'})`)

            } catch (error) {
                console.error("매칭 중 오류:", error);
            }
        });

        socket.on('startGame', () => {
            const roomId = socket.room;
            const roomInfo = getRoomInfo(roomId);
            if (!roomInfo) return;
        
            const playerId = socket.id;
            if (!roomReadyStatus[roomId]) {
                roomReadyStatus[roomId] = {};
            }
            roomReadyStatus[roomId][playerId] = true;
        
            const player1Ready = roomReadyStatus[roomId][roomInfo.player1SocketId];
            const player2Ready = roomReadyStatus[roomId][roomInfo.player2SocketId];
        
            if (player1Ready && player2Ready)
                roomInfo.gameStarted = true;
        });

        socket.on('placeStone', (data) => { // 착수 정보를 받아오고, 상대방에게 전달
            const { row, col } = data;
            const roomId = socket.room;
            const roomInfo = getRoomInfo(roomId);
            if (!roomInfo) return;
        
            const playerNickname = socket.nickname;
            const playerColor = (socket.id === roomInfo.player1SocketId) ?
                                (roomInfo.player1Color === STONE_BLACK ? "Black" : "White") :
                                (roomInfo.player2SocketId && socket.id === roomInfo.player2SocketId) ?
                                (roomInfo.player2Color === STONE_BLACK ? "Black" : "White") :
                                null; // 예외 처리
        
            if (playerColor) {
                roomInfo.turnCount++;
                const turnNumber = roomInfo.turnCount;
        
                roomInfo.moves.push({
                    TurnNumber: turnNumber,
                    Player: playerColor,
                    X: col,
                    Y: row
                });
        
                io.to(roomId).emit('stonePlaced', { row, col });
            } else {
                console.error(`[${roomId}] 알 수 없는 플레이어의 착수: ${playerNickname} (${socket.id})`);
            }
        });

        // 클라이언트에서 게임 종료를 알리는 이벤트 핸들러 추가
        socket.on('gameEnded', async (data) => {
            const roomId = socket.room;
            const roomInfo = getRoomInfo(roomId);
            if (roomInfo && roomInfo.gameStarted) { // 먼저 보내온 플레이어의 정보를 받음
                roomInfo.gameStarted = false;
                console.log(`[${roomId}] 방 게임 종료됨.`);

                const { winner, result } = data; // 클라이언트에서 승자 정보와 결과(Win, Lose, Draw)를 받음
                const player1Nickname = roomInfo.player1Nickname;
                const player2Nickname = roomInfo.player2Nickname;
                const player1Color = roomInfo.player1Color;
                const player2Color = roomInfo.player2Color;
                const winningNickname = winner;
                const losingNickname = winningNickname === player1Nickname ? player2Nickname : player1Nickname;

                const db = socket.request.app.get('database');
                const users = db.collection('users');

                // 게임 결과에 따라 승패 기록 및 게임 기록 저장
                if (result === Win) {
                    await saveGameRecord(socket.request, player1Nickname, player2Nickname, Win, roomInfo.moves, player1Color, player2Color);
                    await updateWinLose(socket.request, winningNickname, true);
                    await updateWinLose(socket.request, losingNickname, false);
                    console.log(`[${roomId}] 게임 종료 - 승자: ${winningNickname}, 패자: ${losingNickname}`);

                    // 랭크 업데이트
                    await updateRank(socket.request, winningNickname, Win);
                    await updateRank(socket.request, losingNickname, Lose);

                } else if (result === Lose) {
                    await saveGameRecord(socket.request, player1Nickname, player2Nickname, Lose, roomInfo.moves, player1Color, player2Color);
                    await updateWinLose(socket.request, winningNickname, true);
                    await updateWinLose(socket.request, losingNickname, false);
                    console.log(`[${roomId}] 게임 종료 - 승자: ${winningNickname}, 패자: ${losingNickname}`);

                    // 랭크 업데이트
                    await updateRank(socket.request, winningNickname, Win);
                    await updateRank(socket.request, losingNickname, Lose);

                } else if (result === Draw) {
                    await saveGameRecord(socket.request, player1Nickname, player2Nickname, Draw, roomInfo.moves, player1Color, player2Color);
                    console.log(`[${roomId}] 게임 종료 - 무승부`);
                    // 무승부 시 랭크 변동 없음 (현재 로직 기준)
                }
            }
            else if (!roomInfo) {
                console.log("방이 존재하지 않습니다.");
            }
            else {
                console.log("")
            }
        });

        // 기권 요청 처리
        socket.on('resignGame', async () => {
            const roomId = socket.room;
            const roomInfo = getRoomInfo(roomId);
            if (!roomInfo.gameStarted) {
                console.log("이미 게임이 종료되어 기권을 반려합니다.");
                return;
            }
            else if (!roomInfo) {
                console.log("방이 존재하지 않습니다.");
            }

            const resigningPlayerNickname = socket.nickname;
            const resigningPlayerId = socket.id;
            const opponentSocketId = resigningPlayerId === roomInfo.player1SocketId ? roomInfo.player2SocketId : roomInfo.player1SocketId;
            const opponentNickname = resigningPlayerId === roomInfo.player1SocketId ? roomInfo.player2Nickname : roomInfo.player1Nickname;
            const player1Color = roomInfo.player1Color;
            const player2Color = roomInfo.player2Color;

            // 상대방에게 기권 소식을 알림
            io.to(opponentSocketId).emit('opponentResigned', { winnerNickname: opponentNickname, loserNickname: resigningPlayerNickname });
            // 자신에게도 알림
            socket.emit('resigned', { opponentNickname: opponentNickname });

            // 게임 종료 처리
            roomInfo.gameStarted = false;

            // 승패 기록 저장 (기권한 플레이어는 Lose)
            const winnerResult = Win;
            const loserResult = Lose;

            if (resigningPlayerId === roomInfo.player1SocketId) {
                await saveGameRecord(socket.request, resigningPlayerNickname, opponentNickname, loserResult, roomInfo.moves, player1Color, player2Color);
                await updateWinLose(socket.request, resigningPlayerNickname, false); // 패배 기록
                await updateWinLose(socket.request, opponentNickname, true);    // 승리 기록
                // 랭크 업데이트
                await updateRank(socket.request, opponentNickname, winnerResult);
                await updateRank(socket.request, resigningPlayerNickname, loserResult);

            } else if (resigningPlayerId === roomInfo.player2SocketId) { // player2인지 명시적으로 확인
                await saveGameRecord(socket.request, opponentNickname, resigningPlayerNickname, winnerResult, roomInfo.moves, player1Color, player2Color);
                await updateWinLose(socket.request, opponentNickname, true);
                await updateWinLose(socket.request, resigningPlayerNickname, false);
                await updateRank(socket.request, opponentNickname, winnerResult);
                await updateRank(socket.request, resigningPlayerNickname, loserResult);
            } else {
                console.error(`[${roomId}] 외부의 비정상적인 기권 요청: ${resigningPlayerNickname} (${resigningPlayerId})`);
                return;
            }

            console.log(`[${resigningPlayerNickname}] 님이 방 ${roomId} 에서 기권했습니다. 승자: ${opponentNickname}`);

            // deleteRoom(roomId);
            io.to(roomId).emit('gameEndedByResign'); // 클라이언트에게 게임 종료를 알리는 추가 이벤트
        });

        //#region 무승부 처리 이벤트들
        socket.on('requestDraw', () => { // 무승부 요청 정보를 받아오고 상대방에게 전달
            const roomId = socket.room;
            const roomInfo = getRoomInfo(roomId);
            if (!roomInfo) return;

            const requesterNickname = socket.nickname; // 무승부 요청한 사람의 닉네임
            const opponentSocketId = socket.id === roomInfo.player1SocketId ? roomInfo.player2SocketId : roomInfo.player1SocketId;

            if (opponentSocketId) {
                io.to(opponentSocketId).emit('opponentRequestedDraw', { requesterNickname });
                console.log(`[${requesterNickname}] 님이 방 ${roomId} 에 무승부를 요청했습니다.`);

                // 무승부 요청 상태를 방 정보에 저장
                roomInfo.drawRequestedBy = socket.id;

            } else {
                console.log("상대방이 방에 없습니다.");
            }
        });

        socket.on('acceptDraw', async () => { // 무승부 수락 정보를 받아오고 상대방에게 전달
            const roomId = socket.room;
            const roomInfo = getRoomInfo(roomId);
            roomInfo.gameStarted = false;
            if (!roomInfo) return;

            const accepterNickname = socket.nickname; // 무승부 수락한 사람의 닉네임
            const player1Color = roomInfo.player1Color;
            const player2Color = roomInfo.player2Color;

            // 양쪽 플레이어가 모두 동의했으므로 무승부 처리
            io.to(roomId).emit('gameDraw');
            console.log(`[${accepterNickname}] 님이 방 ${roomId} 의 무승부 요청을 수락했습니다. 게임 무승부 처리.`);

            // 게임 기록 저장 (결과는 Draw로 설정)
            await saveGameRecord(socket.request, roomInfo.player1Nickname, roomInfo.player2Nickname, Draw, roomInfo.moves, player1Color, player2Color); // 수정

            // 방 종료 (원할 시)
            //deleteRoom(roomId);
        });

        socket.on('rejectDraw', () => { // 무승부 거절 정보를 받아오고 상대방에게 전달
            const roomId = socket.room;
            const roomInfo = getRoomInfo(roomId);
            if (!roomInfo) return;

            const rejecterNickname = socket.nickname; // 무승부 거절한 사람의 닉네임
            const requesterSocketId = roomInfo.drawRequestedBy; // 누가 요청했는지 확인

            if (requesterSocketId) {
                io.to(requesterSocketId).emit('drawRejected', { rejecterNickname });
                console.log(`[${rejecterNickname}] 님이 방 ${roomId} 의 무승부 요청을 거절했습니다.`);
                roomInfo.drawRequestedBy = null; // 무승부 요청 상태 초기화
            }
        });

        //#region 재대국 처리 이벤트들
        // 재대국 요청 처리
        socket.on('requestRematch', async () => {
            const roomId = socket.room;
            const roomInfo = getRoomInfo(roomId);
            if (!roomInfo) {
                return;
            }

            const requesterNickname = socket.nickname;
            const opponentSocketId = socket.id === roomInfo.player1SocketId ? roomInfo.player2SocketId : roomInfo.player1SocketId;
            const opponentNickname = socket.id === roomInfo.player1SocketId ? roomInfo.player2Nickname : roomInfo.player1Nickname;

            const db = socket.request.app.get('database');
            const users = db.collection('users');

            try {
                const requesterData = await users.findOne({ nickname: requesterNickname });
                if (!requesterData || (requesterData.coins || 0) < coinConsumption) {
                    console.log(`[${requesterNickname}] 코인 부족으로 재대국 신청 실패.`);
                    return;
                }

                if (opponentSocketId) {
                    io.to(opponentSocketId).emit('rematchRequested', { requesterNickname: requesterNickname, roomId: roomId });
                    console.log(`[${requesterNickname}] 님이 방 ${roomId} 에서 [${opponentNickname}] 님에게 재대국을 요청했습니다.`);
                } else {
                    socket.emit('error', { message: '상대방이 방에 없습니다.' });
                }
            } catch (error) {
                console.error("재대국 요청 중 오류:", error);
            }
        });

        // 재대국 수락 처리
    socket.on('acceptRematch', async (data) => {
        const { roomId } = data;
        const currentRoomInfo = getRoomInfo(roomId);
        if (!currentRoomInfo) {
            return;
        }

        const acceptingPlayerSocket = socket;
        const opponentSocketId = acceptingPlayerSocket.id === currentRoomInfo.player1SocketId ? currentRoomInfo.player2SocketId : currentRoomInfo.player1SocketId;
        const opponentSocket = io.sockets.sockets.get(opponentSocketId);

        const requesterNickname = currentRoomInfo.player1SocketId === opponentSocketId ? currentRoomInfo.player1Nickname : currentRoomInfo.player2Nickname; // 재대국 요청자 닉네임 확인

        const db = socket.request.app.get('database');
        const users = db.collection('users');

        try {
            const requesterData = await users.findOne({ nickname: requesterNickname });
            if (!requesterData || (requesterData.coins || 0) < coinConsumption) {
                console.log(`[${requesterNickname}] 코인 부족으로 재대국 수락 실패.`);
                return;
            }

            // 코인 차감 (재대국 신청자에게만)
            await users.updateOne({ nickname: requesterNickname }, { $inc: { coins: -coinConsumption } });
            console.log(`[코인 차감] ${requesterNickname}: -${coinConsumption} (재대국)`);

            if (opponentSocket) {
                // 새로운 방 ID 생성
                const newRoomId = uuidv4();

                // 새로운 방 정보 생성
                gameRooms[newRoomId] = {
                    player1SocketId: currentRoomInfo.player1SocketId,
                    player1Email: currentRoomInfo.player1Email,
                    player1Nickname: currentRoomInfo.player1Nickname,
                    player1Color: currentRoomInfo.player1Color,

                    player2SocketId: currentRoomInfo.player2SocketId,
                    player2Email: currentRoomInfo.player2Email,
                    player2Nickname: currentRoomInfo.player2Nickname,
                    player2Color: currentRoomInfo.player2Color,

                    roomId: newRoomId,
                    gameStarted: false, // 초기값 유지
                    player1Disconnected: false,
                    player2Disconnected: false,
                    drawRequestedBy: null,
                    turnCount: 0,
                    moves: []
                };

                // 랜덤으로 색깔 결정
                const randomNumber = Math.floor(Math.random() * 2);
                let player1Color, player2Color;

                if (randomNumber === 0) {
                    player1Color = STONE_BLACK;
                    player2Color = STONE_WHITE;
                } else {
                    player1Color = STONE_WHITE;
                    player2Color = STONE_BLACK;
                }

                // 각 플레이어를 새로운 방에 조인
                acceptingPlayerSocket.leave(roomId);
                acceptingPlayerSocket.join(newRoomId);
                acceptingPlayerSocket.room = newRoomId;

                opponentSocket.leave(roomId);
                opponentSocket.join(newRoomId);
                opponentSocket.room = newRoomId;

                // 각 플레이어에게 새로운 방 ID 및 색깔 정보 전송
                acceptingPlayerSocket.emit('roomCreatedForRematch', { roomId: newRoomId });
                acceptingPlayerSocket.emit('sendInfo', { opponentNickname: currentRoomInfo.player2Nickname, myColor: player1Color, roomId: newRoomId });

                opponentSocket.emit('roomCreatedForRematch', { roomId: newRoomId });
                opponentSocket.emit('sendInfo', { opponentNickname: currentRoomInfo.player1Nickname, myColor: player2Color, roomId: newRoomId });

                // 색을 각 클라이언트 화면에 표시 or 룰렛 연출 시작 신호
                io.to(newRoomId).emit('showColor');

                console.log(`[${acceptingPlayerSocket.nickname}] 님과 [${opponentSocket.nickname}] 님의 재대국 방 생성 (ID: ${newRoomId})`);

                // 이전 방 삭제
                deleteRoom(roomId);
            } else {
                console.log("상대방이 방에 없습니다.");
            }
        } catch (error) {
            console.error("재대국 수락 중 오류:", error);
        }
        });

        // 재대국 거절 처리
        socket.on('rejectRematch', (data) => {
            const { roomId } = data;
            const roomInfo = getRoomInfo(roomId);
            if (!roomInfo) {
                return;
            }

            const rejectingPlayerNickname = socket.nickname;
            const opponentSocketId = socket.id === roomInfo.player1SocketId ? roomInfo.player2SocketId : roomInfo.player1SocketId;

            if (opponentSocketId) {
                io.to(opponentSocketId).emit('rematchRejected', { rejecterNickname: rejectingPlayerNickname, roomId: roomId });
                console.log(`[${rejectingPlayerNickname}] 님이 방 ${roomId} 에서 재대국 요청을 거절했습니다.`);
            } else {
                socket.emit('error', { message: '상대방이 방에 없습니다.' });
            }
        });
        //#endregion

        // TODO: 클라이언트 측에서 Dispose 하기
        socket.on('leaveRoom', (data) => { // 방 이탈 정보를 받아오고 상대방에게 전달
            const { roomId } = data;
            const roomInfo = getRoomInfo(roomId);
            if (!roomInfo) return;

            socket.isLeaveRoom = true;

            const isPlayer1 = socket.id === roomInfo.player1SocketId;
            if (isPlayer1) {
                roomInfo.player1Disconnected = true;
                console.log(`[${roomInfo.player1Nickname}] 님이 방 ${roomId} 에서 나갔습니다.`);
                io.to(roomId).emit('exitRoom');
            } else if (socket.id === roomInfo.player2SocketId) {
                roomInfo.player2Disconnected = true;
                console.log(`[${roomInfo.player2Nickname}] 님이 방 ${roomId} 에서 나갔습니다.`);
                io.to(roomId).emit('exitRoom');
            }
        });

        // TODO: 클라이언트에서 Application.Quit 했을 때 소켓을 Dispose 해줘야함
        socket.on('disconnect', async () => { // 연결이 끊어졌거나 클라이언트 측에서 socket을 Dispose 했을 때 하는 행동
            console.log('클라이언트 연결 해제:', socket.id);
            for (const roomId in gameRooms) {
                const roomInfo = getRoomInfo(roomId);
                if (!roomInfo) continue;
        
                const isPlayer1 = socket.id === roomInfo.player1SocketId;
                const isPlayer2 = socket.id === roomInfo.player2SocketId;
        
                if (isPlayer1) {
                    roomInfo.player1Disconnected = true;
                    // 게임 중일 때, 상대방이 아직 접속해 있고, 명시적인 방 나가기가 아니었을 경우
                    if (roomInfo.player2SocketId && roomInfo.gameStarted && !roomInfo.player2Disconnected && !socket.isLeaveRoom) {
                        const winnerNickname = roomInfo.player2Nickname;
                        io.to(roomInfo.player2SocketId).emit('opponentDisconnectedGameplay', { winner: winnerNickname });
                        await saveGameRecord(socket.request, roomInfo.player1Nickname, roomInfo.player2Nickname, Lose, roomInfo.moves, roomInfo.player1Color, roomInfo.player2Color);
                        await updateWinLose(socket.request, roomInfo.player1Nickname, false); // 패배 기록 (나간 사람)
                        await updateWinLose(socket.request, roomInfo.player2Nickname, true);   // 승리 기록 (남은 사람)
                        // 랭크 업데이트 (player2 승리, player1 패배)
                        await updateRank(socket.request, roomInfo.player2Nickname, RankWin);
                        await updateRank(socket.request, roomInfo.player1Nickname, RankLose);                        
                        console.log(`[${roomInfo.player1Nickname}] 님이 게임 중 연결을 끊어 [${roomInfo.player2Nickname}] 님 승리 처리`);
                    }
                    // 게임 시작 전에, 상대방이 아직 접속해 있고, 명시적인 방 나가기가 아니었을 경우
                    else if (roomInfo.player2SocketId && !roomInfo.gameStarted && !roomInfo.player2Disconnected && !socket.isLeaveRoom) {
                        io.to(roomInfo.player2SocketId).emit('opponentDisconnectedBeforeStart');
                        console.log(`[${roomInfo.player1Nickname}] 님이 게임 시작 전 연결을 끊었습니다.`);
                    }
                    // 상대방이 없거나, 상대방도 이미 연결이 끊어졌을 경우
                    else if (!roomInfo.player2SocketId || (roomInfo.player2Disconnected && roomInfo.player1Disconnected)) {
                        console.log(`[${roomInfo.player1Nickname}] 님의 연결 끊김으로 방 ${roomId} 삭제`);
                        deleteRoom(roomId);
                    }
                } else if (isPlayer2) {
                    roomInfo.player2Disconnected = true;
                    // 게임 중일 때, 상대방이 아직 접속해 있고, 명시적인 방 나가기가 아니었을 경우
                    if (roomInfo.player1SocketId && roomInfo.gameStarted && !roomInfo.player1Disconnected && !socket.isLeaveRoom) {
                        const winnerNickname = roomInfo.player1Nickname;
                        io.to(roomInfo.player1SocketId).emit('opponentDisconnectedGameplay', { winner: winnerNickname });
                        await saveGameRecord(socket.request, roomInfo.player2Nickname, roomInfo.player1Nickname, Lose, roomInfo.moves, roomInfo.player2Color, roomInfo.player1Color);
                        await updateWinLose(socket.request, roomInfo.player2Nickname, false); // 패배 기록 (나간 사람)
                        await updateWinLose(socket.request, roomInfo.player1Nickname, true);   // 승리 기록 (남은 사람)
                        // 랭크 업데이트 (player1 승리, player2 패배)
                        await updateRank(socket.request, roomInfo.player1Nickname, RankWin);
                        await updateRank(socket.request, roomInfo.player2Nickname, RankLose);                        
                        console.log(`[${roomInfo.player2Nickname}] 님이 게임 중 연결을 끊어 [${roomInfo.player1Nickname}] 님 승리 처리`);
                    }
                    // 게임 시작 전에, 상대방이 아직 접속해 있고, 명시적인 방 나가기가 아니었을 경우
                    else if (roomInfo.player1SocketId && !roomInfo.gameStarted && !roomInfo.player1Disconnected && !socket.isLeaveRoom) {
                        io.to(roomInfo.player1SocketId).emit('opponentDisconnectedBeforeStart');
                        console.log(`[${roomInfo.player2Nickname}] 님이 게임 시작 전 연결을 끊었습니다.`);
                    }
                    // 상대방이 없거나, 상대방도 이미 연결이 끊어졌을 경우
                    else if (!roomInfo.player1SocketId || (roomInfo.player1Disconnected && roomInfo.player2Disconnected)) {
                        console.log(`[${roomInfo.player2Nickname}] 님의 연결 끊김으로 방 ${roomId} 삭제`);
                        deleteRoom(roomId);
                    }
                }
            }
        });

    });
};