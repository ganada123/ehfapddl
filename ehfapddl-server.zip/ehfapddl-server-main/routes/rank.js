const express = require('express');
const router = express.Router();
const moment = require('moment-timezone');

// 급수 시스템 기준
const rankUpPoints = {
    18: 3, 17: 3, 16: 3, 15: 3, 14: 3, 13: 3, 12: 3, 11: 3, // 10~17급으로 승급
    10: 5, 9: 5, 8: 5, 7: 5, 6: 5,   // 5~9급으로 승급
    5: 10, 4: 10, 3: 10, 2: 10       // 1~4 급으로 승급
};
const demotionPoints = -3;
const maxRank = 1;
const minRank = 18;

// TODO: 클라이언트에 맞게 수정 result는 ex) WIN: 0, LOSE: 1, DRAW: 2
const Win = 0;
const Lose = 1;


// 게임 결과 업데이트 및 급수 변경
router.post('/updaterank', async (req, res) => {
    try {
        if (!req.session.isAuthenticated) {
            return res.status(401).send("로그인이 필요합니다.");
        }

        const db = req.app.get('database');
        const users = db.collection('users');
        const userNickname = req.session.user.nickname;
        const { gameResult } = req.body; // TODO: 클라이언트에 맞게 수정, 0: 'win', 1: 'lose', 2: 'draw'

        const user = await users.findOne(
            { nickname: userNickname },
            { projection: {
                rank: 1,
                rankPoints: 1,
                win: 1,
                lose: 1
            }});

        if (!user) {
            return res.status(404).send("사용자를 찾을 수 없습니다.");
        }

        let { rank, rankPoints, win, lose } = user;
        let updatedRank = rank;
        let updatedRankPoints = rankPoints || 0;
        let updatedWin = win;
        let updatedLose = lose;

        if (gameResult === Win) {
            updatedRankPoints++;
            updatedWin++;
        } else if (gameResult === Lose) {
            updatedRankPoints--;
            updatedLose++;
        }

        const requiredPoints = rankUpPoints[rank];
        if (requiredPoints && updatedRankPoints >= requiredPoints && rank > maxRank) {
            updatedRank--;
            updatedRankPoints = 0;
        }

        if (updatedRankPoints <= demotionPoints && rank < minRank) {
            updatedRank++;
            updatedRankPoints = 0;
        }

        if (updatedRank < maxRank) updatedRank = maxRank;
        if (updatedRank > minRank) updatedRank = minRank;

        const updateSet = { rank: updatedRank, rankPoints: updatedRankPoints, win: updatedWin, lose: updatedLose };
        if (updatedRank !== rank) {
            updateSet.rankAchievedTime = moment().tz('Asia/Seoul').toDate(); // 한국 시간으로 설정 (Date 객체)
        }

        await users.updateOne(
            { nickname: userNickname },
            { $set: updateSet }
        );

        res.status(200).send({ message: "급수가 업데이트되었습니다.", newRank: updatedRank, newRankPoints: updatedRankPoints, newWin: updatedWin, newLose: updatedLose });

    } catch (error) {
        console.error("급수 업데이트 오류:", error);
        res.status(500).send("서버 오류가 발생했습니다.");
    }
});

router.get('/getrank', async (req, res) => {
    try {
        if (!req.session.isAuthenticated) {
            return res.status(401).send("로그인이 필요합니다.");
        }
    
        const db = req.app.get('database');
        const users = db.collection("users");
        const userNickname = req.session.user.nickname;

        const userRank = await users.findOne(
            { nickname: userNickname }, 
            { projection: {
                 rank: 1,
                 rankPoints: 1
            }}); 

        if (!userRank) {
            return res.status(404).send("사용자를 찾을 수 없습니다.")
        }

        const result = { rank: userRank.rank, rankPoints: userRank.rankPoints };
    
        res.status(200).json(result);
    } catch (err) {
        console.error("급수 불러오기 오류:", error);
        res.status(500).send("서버 오류가 발생했습니다.");
    }
});

module.exports = {router, rankUpPoints, demotionPoints, maxRank, minRank}; // users.js, gamePlay.js 에서 사용하기 위한 exports