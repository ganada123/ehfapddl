var express = require('express');
var router = express.Router();
const moment = require('moment-timezone');

router.get('/getranking', async function(req, res, next) {
    try {
        if (!req.session.isAuthenticated) {
            return res.status(400).send("로그인이 필요합니다.");
        }

        var database = req.app.get('database');
        var users = database.collection('users');

        const allUsers = await users.find({}, {
            projection: {
                nickname: 1,
                rank: 1,
                win: 1,
                lose: 1,
                rankAchievedTime: 1
            }
        }).toArray();

        // 급수(rank)로 먼저 정렬하고, 같은 급수 내에서 승률, 마지막으로 랭킹 달성 시간으로 정렬
        const userRankList = allUsers
            .map(user => ({
                nickname: user.nickname,
                rank: user.rank,
                win: user.win,
                lose: user.lose,
                rankAchievedTime: user.rankAchievedTime
            }))
            .sort((a, b) => {
                // 먼저 급수(rank)로 정렬 (급수가 낮을수록 더 높은 순위)
                if (a.rank !== b.rank) {
                    return a.rank - b.rank;
                }
                // 같은 급수 내에서는 승률로 정렬 (승률이 높을수록 더 높은 순위)
                const aWinRate = a.win + a.lose > 0 ? (a.win / (a.win + a.lose)) * 100 : 0;
                const bWinRate = b.win + b.lose > 0 ? (b.win / (b.win + b.lose)) * 100 : 0;
                if (bWinRate !== aWinRate) {
                    return bWinRate - aWinRate;
                }
                // 승률이 같은 경우, 랭킹 달성 시간으로 정렬 (오래된 순서대로 더 높은 순위)
                const timeA = a.rankAchievedTime ? new Date(a.rankAchievedTime).getTime() : null;
                const timeB = b.rankAchievedTime ? new Date(b.rankAchievedTime).getTime() : null;
            
                if (timeA && timeB) {
                    return timeA - timeB; // 이전 시간이 더 높은 순위
                } else if (timeA) {
                    return -1; // a는 랭킹 달성 시간이 있고 b는 없으면 a가 더 높음
                } else if (timeB) {
                    return 1;  // b는 랭킹 달성 시간이 있고 a는 없으면 b가 더 높음
                }
                return 0; // 둘 다 랭킹 달성 시간이 없으면 순서 유지
            });

        // 랭킹 순위 추가
        const rankedUserList = userRankList.map((user, index) => ({
            ...user,
            rankingPosition: index + 1 // 인덱스에 1을 더하여 1등부터 시작
        }));

        const result = {
            ranking : rankedUserList
        };

        res.status(200).json(result);

    } catch (err) {
        console.error("랭킹 보드 조회 중 오류 발생 : ", err);
        res.status(500).send("서버 오류가 발생했습니다.");
    }
});

// 테스트용 라우터 랭킹 추가
router.post('/addranking', async function(req, res, next){
    try {
        if (!req.session.isAuthenticated) {
            return res.status(400).send("로그인이 필요합니다.");
        }
        var database = req.app.get('database');
        var users = database.collection('users');

        // 1급~18급 (1급이 가장 높은 급수)
        const rank = parseInt(req.body.rank);
        if (isNaN(rank) || rank < 1 || rank > 18) {
            return res.status(400).send("유효하지 않은 급수입니다.");
        }

        await users.insertOne({
            nickname: req.body.nickname,
            rank: req.body.rank,
            win: req.body.win || 0, // 값이 있으면 값을 그대로 할당, 값이 없으면 0을 할당당
            lose: req.body.lose || 0,
            rankAchievedTime: moment().tz('Asia/Seoul').toDate() // 한국 시간으로 설정 (Date 객체)
        });
        res.status(201).send("랭킹이 정상적으로 추가되었습니다.");
    } catch (err) {
        console.error("랭킹 추가 중 오류 발생:", err);
        res.status(500).send("서버 오류가 발생했습니다");
    }
});

module.exports = router;