const express = require('express');
const { todo } = require('node:test');
const router = express.Router();

const coinConsumption = 100;
const adReward = 500;
const purchaseOptions = { // TODO: 클라이언트에 맞게 수정
    '1000': 3000,   // 1000원, 3000코인
    '1800': 6000,   // 1800원, 6000코인
    '2500': 10000   // 2500원, 10000코인
};

// 코인 차감
router.post('/consume', async (req, res) => {
    try {
        if (!req.session.isAuthenticated) {
            return res.status(401).send("로그인이 필요합니다.");
        }

        const db = req.app.get('database');
        const users = db.collection('users');
        const userNickname = req.session.user.nickname;
        const { amount } = req.body;

        const user = await users.findOne({ nickname: userNickname });
        if (!user || (user.coins || 0) < amount) { // coins 필드가 없을 경우 0으로 처리
            return res.status(400).send("코인이 부족합니다.");
        }

        await users.updateOne(
            { nickname: userNickname },
            { $inc: { coins: -amount } }
        );

        res.status(200).send({ message: `${amount} 코인이 차감되었습니다.` });

    } catch (error) {
        console.error("코인 차감 오류:", error);
        res.status(500).send("서버 오류가 발생했습니다.");
    }
});

// 광고 시청 보상
router.post('/rewardad', async (req, res) => {
    try {
        if (!req.session.isAuthenticated) {
            return res.status(401).send("로그인이 필요합니다.");
        }

        const db = req.app.get('database');
        const users = db.collection('users');
        const userNickname = req.session.user.nickname;

        await users.updateOne(
            { nickname: userNickname },
            { $inc: { coins: adReward } }
        );

        res.status(200).send({ message: `${adReward} 코인이 지급되었습니다.` });

    } catch (error) {
        console.error("광고 시청 보상 오류:", error);
        res.status(500).send("서버 오류가 발생했습니다.");
    }
});

// 코인 구매
router.post('/purchase', async (req, res) => {
    try {
        if (!req.session.isAuthenticated) {
            return res.status(401).send("로그인이 필요합니다.");
        }

        const db = req.app.get('database');
        const users = db.collection('users');
        const userNickname = req.session.user.nickname;
        const { purchaseAmount } = req.body;

        const coinsToGive = purchaseOptions[purchaseAmount];
        if (!coinsToGive) {
            return res.status(400).send("유효하지 않은 구매 금액입니다.");
        }

        await users.updateOne(
            { nickname: userNickname },
            { $inc: { coins: coinsToGive } }
        );

        res.status(200).send({ message: `${coinsToGive} 코인이 지급되었습니다.` });

    } catch (error) {
        console.error("코인 구매 오류:", error);
        res.status(500).send("서버 오류가 발생했습니다.");
    }
});

// 현재 코인 잔액 조회
router.get('/getbalance', async (req, res) => {
    try {
        if (!req.session.isAuthenticated) {
            return res.status(401).send("로그인이 필요합니다.");
        }

        const db = req.app.get('database');
        const users = db.collection('users');
        const userNickname = req.session.user.nickname;

        const user = await users.findOne({ nickname: userNickname }, { projection: { _id: 0, coins: 1 } }); // 닉네임으로 사용자 찾기
        if (!user) {
            return res.status(404).send("사용자를 찾을 수 없습니다.");
        }

        res.status(200).json({ coins: user.coins || 0 });

    } catch (error) {
        console.error("코인 잔액 조회 오류:", error);
        res.status(500).send("서버 오류가 발생했습니다.");
    }
});

module.exports = { router, coinConsumption };